package com.aira.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var onTranscript: ((String) -> Unit)? = null
    private var onStatus: ((String) -> Unit)? = null
    private var isListening = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else onStatus?.invoke("Microphone permission zaroori hai.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            AiraScreen(
                onMic = { transcript, status ->
                    onTranscript = transcript
                    onStatus = status
                    ensurePermissionAndListen()
                },
                onStop = {
                    stopListening()
                    onStatus?.invoke("Listening band hai.")
                }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            tts?.setSpeechRate(0.96f)
        }
    }

    private fun ensurePermissionAndListen() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) startListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onStatus?.invoke("Is phone par speech recognition available nahi hai.")
            return
        }
        stopListening()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("Sun rahi hoon… bolo “Hey Aira” ya apna sawal.") }
            override fun onBeginningOfSpeech() { onStatus?.invoke("Listening…") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("Aapki baat process ho rahi hai…") }
            override fun onError(error: Int) {
                isListening = false
                onStatus?.invoke("Sunna ruk gaya. Dobara mic dabayein.")
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onTranscript?.invoke(text)
                onStatus?.invoke("Ready")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Aira se Hindi mein baat karein")
        }
        isListening = true
        speechRecognizer?.startListening(intent)
    }

    private fun stopListening() {
        try { speechRecognizer?.stopListening(); speechRecognizer?.cancel(); speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        isListening = false
    }

    override fun onDestroy() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Composable
    private fun AiraScreen(onMic: ((String) -> Unit, (String) -> Unit) -> Unit, onStop: () -> Unit) {
        var status by remember { mutableStateOf("Namaste! Main Aira hoon.") }
        var heard by remember { mutableStateOf("") }
        var answer by remember { mutableStateOf("Mic dabakar Hindi mein baat shuru karein.") }
        var waiting by remember { mutableStateOf(false) }

        val bg = Brush.verticalGradient(listOf(Color(0xFF070B20), Color(0xFF11153A), Color(0xFF070B20)))
        val transition = rememberInfiniteTransition(label = "orb")
        val pulse by transition.animateFloat(
            initialValue = 0.94f, targetValue = 1.08f,
            animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
            label = "pulse"
        )

        MaterialTheme(colorScheme = darkColorScheme()) {
            Box(
                modifier = Modifier.fillMaxSize().background(bg).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("AIRA", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                    Text("YOUR PERSONAL AI", color = Color(0xFF9CB6FF), fontSize = 11.sp, letterSpacing = 3.sp)
                    Spacer(Modifier.height(18.dp))
                    Box(
                        modifier = Modifier.size(210.dp).scale(pulse)
                            .background(
                                Brush.radialGradient(listOf(Color(0xFF8D76FF), Color(0xFF2B6FEA), Color(0x0030CFFF))),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier.size(126.dp).background(
                                Brush.radialGradient(listOf(Color(0xFFB7F7FF), Color(0xFF5389FF), Color(0xFF7A45E8))),
                                CircleShape
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("P", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Light)
                        }
                    }
                    Text(status, color = Color(0xFFDDE5FF), fontSize = 15.sp, textAlign = TextAlign.Center)
                    if (heard.isNotBlank()) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171D42)), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Aapne kaha", color = Color(0xFF91B7FF), fontSize = 12.sp)
                                Text(heard, color = Color.White)
                                Text("AI jawab ke liye backend connect karna baaki hai.", color = Color(0xFFCAD2F5), fontSize = 13.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            waiting = true
                            onMic(
                                { text ->
                                    heard = text
                                    val normalized = text.lowercase(Locale.ROOT)
                                    answer = if (normalized.contains("hey aira") || normalized.contains("हे प्रिशा")) {
                                        "Haan, main sun rahi hoon. Bataiye, main kya madad karoon?"
                                    } else {
                                        "Aapne kaha: $text. Online AI jawab paane ke liye backend connect karein."
                                    }
                                    tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "aira-answer")
                                    status = "Jawab diya ja raha hai…"
                                    waiting = false
                                },
                                { newStatus -> status = newStatus; waiting = newStatus.contains("Sun rahi") || newStatus.contains("Listening") }
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(30.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5B65F5))
                    ) {
                        Text(if (waiting) "SUN RAHI HOON…" else "🎙  BAAT KAREIN", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(28.dp)) {
                        Text("Stop listening", color = Color.White)
                    }
                    Text("Hindi voice • Internet AI setup required", color = Color(0xFF8995C6), fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }
}
