# AIRA AI — Android starter project

This is a starter Android Studio project for the Aira Hindi voice-assistant UI.
It includes a futuristic orb screen, Android speech recognition in Hindi, and Hindi text-to-speech.

## Important current limitations
- This starter is NOT a finished Siri replacement and does not yet include an online AI backend.
- “Hey Aira” is only checked after speech recognition returns text; the sample does not provide reliable always-on wake-word detection.
- Always-on wake-word support requires a dedicated wake-word engine/model and careful Android foreground-service implementation. Android restricts background microphone access, especially on newer versions.
- Do not place an OpenAI/API secret inside the APK. Put the key on a backend server and have the app call your backend.
- Speech recognition availability and whether recognition uses internet depends on the Android device and installed speech service.

## Build the APK
1. Install Android Studio on a Windows/Mac/Linux computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `AiraAI_Android_Starter` folder.
4. Let Gradle sync finish. If Android Studio asks to install Android SDK Platform 35, accept.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run** to test.
7. To make an installable debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`. Transfer it to your phone and allow installation from that source if Android asks.

## Connect online AI safely
Recommended architecture:
Android app -> your HTTPS backend -> AI provider API.
The backend stores the API key in an environment variable or secret manager. The Android app should only know your backend URL. Add authentication, rate limits, and usage limits before sharing the APK.

## App identity
- App name: AIRA AI
- Application ID: `com.aira.assistant`
- Minimum Android: Android 8.0 (API 26)
- Main language: Hindi (`hi-IN`)
